import sys
import os

def check_environment():
    print("Python Environment Check")
    print("======================")
    print(f"Python Version: {sys.version}")
    print(f"Executable: {sys.executable}")
    print(f"Working Directory: {os.getcwd()}")
    print("\nEnvironment Variables:")
    for key in ['PATH', 'PYTHONPATH', 'VIRTUAL_ENV']:
        print(f"{key}: {os.environ.get(key, 'Not set')}")
    
    print("\nTesting Flask import:")
    try:
        import flask
        print(f"Flask version: {flask.__version__}")
    except ImportError:
        print("Flask is not installed")
    
    print("\nTesting requests import:")
    try:
        import requests
        print(f"Requests version: {requests.__version__}")
    except ImportError:
        print("Requests is not installed")

if __name__ == "__main__":
    check_environment()
