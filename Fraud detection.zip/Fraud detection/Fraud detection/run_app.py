import os
import sys
import subprocess

def main():
    print("Starting SEBI Safe Space Application...")
    print("-" * 50)
    
    # Check Python version
    print(f"Python version: {sys.version}")
    
    # Check working directory
    print(f"Working directory: {os.getcwd()}")
    
    # Check if virtual environment exists
    venv_path = os.path.join(os.getcwd(), 'venv')
    if os.path.exists(venv_path):
        print("Virtual environment found.")
        # Activate virtual environment
        if sys.platform == 'win32':
            activate_script = os.path.join(venv_path, 'Scripts', 'activate.bat')
            python_exe = os.path.join(venv_path, 'Scripts', 'python.exe')
        else:
            activate_script = os.path.join(venv_path, 'bin', 'activate')
            python_exe = os.path.join(venv_path, 'bin', 'python')
        
        if os.path.exists(python_exe):
            print(f"Using Python from virtual environment: {python_exe}")
            # Install requirements
            print("Installing requirements...")
            subprocess.call([python_exe, "-m", "pip", "install", "-r", "requirements.txt"])
            
            # Start Flask app
            print("\nStarting Flask application...")
            print("-" * 50)
            os.chdir("fraud_detector")
            os.environ["FLASK_APP"] = "app.py"
            os.environ["FLASK_DEBUG"] = "1"
            subprocess.call([python_exe, "-m", "flask", "run", "--host=0.0.0.0", "--port=5000"])
        else:
            print("Python executable not found in virtual environment.")
    else:
        print("Virtual environment not found. Please set up the virtual environment first.")
        print("Run these commands in the project directory:")
        print("  python -m venv venv")
        print("  .\\venv\\Scripts\\activate")
        print("  pip install -r requirements.txt")

if __name__ == "__main__":
    main()
