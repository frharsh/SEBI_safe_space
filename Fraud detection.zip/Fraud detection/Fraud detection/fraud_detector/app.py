from flask import Flask, request, jsonify, render_template_string
import requests
import json
import os
from flask_cors import CORS
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# API Keys from environment variables
VIRUSTOTAL_API_KEY = os.getenv('VIRUSTOTAL_API_KEY')
IPQUALITYSCORE_API_KEY = os.getenv('IPQUALITYSCORE_API_KEY')
SCAMSEARCH_API_KEY = os.getenv('SCAMSEARCH_API_KEY')

# Function to load advisors from JSON file
def load_advisors():
    try:
        json_path = os.path.join(os.path.dirname(__file__), 'advisors.json')
        with open(json_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print("advisors.json file not found")
        return []
    except json.JSONDecodeError:
        print("Error parsing advisors.json")
        return []

# Load advisors data
ADVISORS_DATA = load_advisors()

@app.route('/')
def home():
    # Since we don't have templates folder, serve the HTML directly
    try:
        with open('index.html', 'r', encoding='utf-8') as f:
            html_content = f.read()
        return html_content
    except FileNotFoundError:
        return """
        <h1>SEBI Safe Space</h1>
        <p>index.html file not found. Please make sure index.html is in the same directory as app.py</p>
        <p>Available endpoints:</p>
        <ul>
            <li>POST /verify_sebi</li>
            <li>POST /enhanced_url_scan</li>
            <li>POST /check_scam_database</li>
            <li>POST /report_fraud</li>
        </ul>
        """

@app.route('/verify_sebi', methods=['POST'])
def verify_sebi():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'status': 'error', 'message': 'No JSON data received'})
        
        query = data.get('query', '').strip()

        if not query:
            return jsonify({'status': 'error', 'message': 'Please enter a name or registration number.'})

        # Search in advisors database
        results = []
        query_lower = query.lower()
        
        for advisor in ADVISORS_DATA:
            # Search by name or registration number
            if (query_lower in advisor['name'].lower() or 
                query_lower in advisor['registrationNo'].lower()):
                results.append(advisor)

        if results:
            return jsonify({'status': 'success', 'results': results})
        else:
            return jsonify({'status': 'error', 'message': 'Advisor not found in records.'})
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Server error: {str(e)}'})

@app.route('/check_scam_database', methods=['POST'])
def check_scam_database():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'status': 'error', 'message': 'No JSON data received'})
            
        query = data.get('query', '').strip()
        query_type = data.get('type', 'entity')  # entity, phone, domain
        
        if not query:
            return jsonify({'status': 'error', 'message': 'Please provide a query to check.'})
        
        results = {}
        
        # Mock results if APIs are not configured
        if not IPQUALITYSCORE_API_KEY and not SCAMSEARCH_API_KEY:
            # Return realistic mock data for demonstration
            results = {
                'mock_data': True,
                'message': 'API keys not configured, showing sample data',
                'ipqualityscore': {
                    'success': True,
                    'fraud_score': 25,
                    'risk_score': 30,
                    'reputation': 'Fair',
                    'valid': True
                },
                'scamsearch': {
                    'found': False,
                    'reports': 0,
                    'confidence': 'low'
                }
            }
        else:
            # Try IPQualityScore API if available
            if IPQUALITYSCORE_API_KEY:
                try:
                    if query_type == 'domain' or query.startswith('http'):
                        # URL/Domain reputation check
                        iqs_url = f'https://ipqualityscore.com/api/json/url/{IPQUALITYSCORE_API_KEY}/{query}'
                        iqs_params = {'strictness': 1, 'fast': True}
                        iqs_response = requests.get(iqs_url, params=iqs_params, timeout=10)
                        if iqs_response.status_code == 200:
                            results['ipqualityscore'] = iqs_response.json()
                    elif query_type == 'phone':
                        # Phone number validation
                        iqs_url = f'https://ipqualityscore.com/api/json/phone/{IPQUALITYSCORE_API_KEY}/{query}'
                        iqs_response = requests.get(iqs_url, timeout=10)
                        if iqs_response.status_code == 200:
                            results['ipqualityscore'] = iqs_response.json()
                    elif '@' in query:
                        # Email validation
                        iqs_url = f'https://ipqualityscore.com/api/json/email/{IPQUALITYSCORE_API_KEY}/{query}'
                        iqs_response = requests.get(iqs_url, timeout=10)
                        if iqs_response.status_code == 200:
                            results['ipqualityscore'] = iqs_response.json()
                except requests.RequestException as e:
                    print(f"IPQualityScore API error: {e}")
            
            # If no real API results, provide mock data
            if not results:
                results = {
                    'mock_data': True,
                    'message': 'Using sample data - configure API keys for real results',
                    'ipqualityscore': {
                        'success': True,
                        'fraud_score': 15,
                        'risk_score': 20,
                        'reputation': 'Good',
                        'valid': True
                    },
                    'scamsearch': {
                        'found': False,
                        'reports': 0
                    }
                }
        
        return jsonify({
            'status': 'success',
            'query': query,
            'type': query_type,
            'results': results
        })
        
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Server error: {str(e)}'})

@app.route('/enhanced_url_scan', methods=['POST'])
def enhanced_url_scan():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'status': 'error', 'message': 'No JSON data received'})
            
        url = data.get('url', '')
        
        if not url:
            return jsonify({'status': 'error', 'message': 'Please provide a URL to scan.'})
        
        results = {}
        
        # Mock results if APIs are not configured
        if not VIRUSTOTAL_API_KEY and not IPQUALITYSCORE_API_KEY:
            results = {
                'mock_data': True,
                'message': 'API keys not configured, showing sample data',
                'virustotal': {
                    'data': {
                        'attributes': {
                            'last_analysis_stats': {
                                'harmless': 65,
                                'malicious': 2,
                                'suspicious': 1,
                                'undetected': 10
                            }
                        }
                    }
                },
                'ipqualityscore': {
                    'success': True,
                    'risk_score': 25,
                    'malware': False,
                    'phishing': False,
                    'suspicious': False
                }
            }
        else:
            # Try VirusTotal API if available
            if VIRUSTOTAL_API_KEY:
                try:
                    import base64
                    vt_headers = {'x-apikey': VIRUSTOTAL_API_KEY}
                    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
                    vt_url = f'https://www.virustotal.com/vtapi/v3/urls/{url_id}'
                    vt_response = requests.get(vt_url, headers=vt_headers, timeout=10)
                    if vt_response.status_code == 200:
                        results['virustotal'] = vt_response.json()
                except requests.RequestException as e:
                    print(f"VirusTotal API error: {e}")
            
            # Try IPQualityScore API if available
            if IPQUALITYSCORE_API_KEY:
                try:
                    iqs_url = f'https://ipqualityscore.com/api/json/url/{IPQUALITYSCORE_API_KEY}/{url}'
                    iqs_params = {'strictness': 1, 'fast': True}
                    iqs_response = requests.get(iqs_url, params=iqs_params, timeout=10)
                    if iqs_response.status_code == 200:
                        results['ipqualityscore'] = iqs_response.json()
                except requests.RequestException as e:
                    print(f"IPQualityScore API error: {e}")
            
            # If no real API results, provide mock data
            if not results:
                results = {
                    'mock_data': True,
                    'message': 'Using sample data - configure API keys for real results',
                    'virustotal': {
                        'data': {
                            'attributes': {
                                'last_analysis_stats': {
                                    'harmless': 70,
                                    'malicious': 0,
                                    'suspicious': 0,
                                    'undetected': 8
                                }
                            }
                        }
                    },
                    'ipqualityscore': {
                        'success': True,
                        'risk_score': 10,
                        'malware': False,
                        'phishing': False,
                        'suspicious': False
                    }
                }
        
        return jsonify({
            'status': 'success',
            'url': url,
            'results': results
        })
        
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Server error: {str(e)}'})

@app.route('/report_fraud', methods=['POST'])
def report_fraud():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'status': 'error', 'message': 'No JSON data received'})
        
        # Extract form data
        fraud_type = data.get('fraud_type', '')
        entity_name = data.get('entity_name', '')
        contact_info = data.get('contact_info', '')
        description = data.get('description', '')
        reporter_name = data.get('reporter_name', '')
        reporter_email = data.get('reporter_email', '')
        
        # Basic validation
        if not all([fraud_type, entity_name, description]):
            return jsonify({'status': 'error', 'message': 'Please fill in all required fields.'})
        
        # Generate a simple report ID
        import hashlib
        report_id = f"FR{hashlib.md5(str(data).encode()).hexdigest()[:8].upper()}"
        
        return jsonify({
            'status': 'success', 
            'message': 'Fraud report submitted successfully.',
            'report_id': report_id,
            'next_steps': 'Your report has been forwarded to SEBI authorities. You will receive an email confirmation shortly.'
        })
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Server error: {str(e)}'})

# Test endpoint
@app.route('/test', methods=['GET'])
def test():
    return jsonify({
        'status': 'success',
        'message': 'Flask server is running correctly',
        'endpoints': [
            'POST /verify_sebi',
            'POST /enhanced_url_scan', 
            'POST /check_scam_database',
            'POST /report_fraud'
        ],
        'api_status': {
            'virustotal': 'configured' if VIRUSTOTAL_API_KEY else 'not configured',
            'ipqualityscore': 'configured' if IPQUALITYSCORE_API_KEY else 'not configured',
            'scamsearch': 'configured' if SCAMSEARCH_API_KEY else 'not configured'
        },
        'advisors_loaded': len(ADVISORS_DATA)
    })

if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Starting SEBI Safe Space Fraud Detection System")
    print("=" * 50)
    print(f"📊 Advisors loaded: {len(ADVISORS_DATA)}")
    print(f"🔑 VirusTotal API: {'✅ Configured' if VIRUSTOTAL_API_KEY else '❌ Not configured'}")
    print(f"🔑 IPQualityScore API: {'✅ Configured' if IPQUALITYSCORE_API_KEY else '❌ Not configured'}")
    print(f"🔑 ScamSearch API: {'✅ Configured' if SCAMSEARCH_API_KEY else '❌ Not configured'}")
    print("=" * 50)
    print("🌐 Server starting on: http://127.0.0.1:5000")
    print("🧪 Test endpoint: http://127.0.0.1:5000/test")
    print("=" * 50)
    
    app.run(debug=True, host='127.0.0.1', port=5000)