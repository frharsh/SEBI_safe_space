#!/usr/bin/env python3
"""
Debug script to test Flask server startup and API endpoints
"""
import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))

print("=== SEBI Safe Space Debug Information ===")
print(f"Python version: {sys.version}")
print(f"Current directory: {os.getcwd()}")
print(f"Script location: {__file__}")

# Check environment variables
print("\n=== Environment Variables ===")
vt_key = os.getenv('VIRUSTOTAL_API_KEY')
iqs_key = os.getenv('IPQUALITYSCORE_API_KEY')
scam_key = os.getenv('SCAMSEARCH_API_KEY')

print(f"VirusTotal API: {'✓ Configured' if vt_key else '✗ Not found'}")
print(f"IPQualityScore API: {'✓ Configured' if iqs_key else '✗ Not found'}")
print(f"ScamSearch API: {'✓ Configured' if scam_key else '✗ Not found'}")

# Check required files
print("\n=== File Check ===")
required_files = [
    'app.py',
    'advisors.json',
    'templates/index.html'
]

for file in required_files:
    if os.path.exists(file):
        print(f"✓ {file} exists")
    else:
        print(f"✗ {file} missing")

# Test imports
print("\n=== Import Test ===")
try:
    import flask
    print(f"✓ Flask {flask.__version__}")
except ImportError as e:
    print(f"✗ Flask import failed: {e}")

try:
    import requests
    print(f"✓ Requests {requests.__version__}")
except ImportError as e:
    print(f"✗ Requests import failed: {e}")

try:
    from flask_cors import CORS
    print("✓ Flask-CORS imported")
except ImportError as e:
    print(f"✗ Flask-CORS import failed: {e}")

# Test Flask app creation
print("\n=== Flask App Test ===")
try:
    from flask import Flask
    app = Flask(__name__)
    
    @app.route('/test')
    def test():
        return {'status': 'success', 'message': 'Flask app is working'}
    
    print("✓ Flask app created successfully")
    
    # Start server
    print("\n=== Starting Debug Server ===")
    print("Server will start on http://127.0.0.1:5000")
    print("Press Ctrl+C to stop")
    app.run(debug=True, host='127.0.0.1', port=5000)
    
except Exception as e:
    print(f"✗ Flask app creation failed: {e}")
    import traceback
    traceback.print_exc()
